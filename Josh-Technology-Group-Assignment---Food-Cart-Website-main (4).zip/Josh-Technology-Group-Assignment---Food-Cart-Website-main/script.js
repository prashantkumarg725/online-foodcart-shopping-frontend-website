// Function to open the modal
function openModal() {
  document.getElementById('cartmodal').style.display = 'flex';
}

// Function to close the modal
function closeModal() {
  document.getElementById('cartmodal').style.display = 'none';
}
function openRequest() {
  document.getElementById('reqmodal').style.display = 'flex';
  window.scrollTo(0, 0);
  }

function closeRequest(){
  document.getElementById('reqmodal').style.display = 'none';
}

const video = document.getElementById('myVideo');
const playPauseBtn = document.getElementById('playPauseBtn');

playPauseBtn.addEventListener('click', () => {
  if (video.paused) {
    video.play();
    playPauseBtn.textContent = 'Pause'; // Change button text to "Pause"
  } else {
    video.pause();
    playPauseBtn.textContent = 'Play'; // Change button text back to "Play"
  }
});

